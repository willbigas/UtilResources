package uteis;

import javax.swing.JOptionPane;

/**
 *
 * @author william.mauro
 */
public class Mensagem {
    
    public static void msg(String texto) {
        JOptionPane.showMessageDialog(null, texto);
    }
    
}
