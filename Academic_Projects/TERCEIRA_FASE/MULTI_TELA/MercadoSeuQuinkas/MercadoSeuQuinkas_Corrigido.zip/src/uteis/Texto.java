package uteis;

/**
 *
 * @author william.mauro
 */
public class Texto {
    
    public static final String NASCIMENTO_INVALIDO = "Data de Nascimento Invalida";
    public static final String CADASTRO_SUCESSO = "Cadastro Realizado com Sucesso!";
    public static final String CADASTRO_ERRO = "Erro ao Realizar o Cadastro!";
    
}
