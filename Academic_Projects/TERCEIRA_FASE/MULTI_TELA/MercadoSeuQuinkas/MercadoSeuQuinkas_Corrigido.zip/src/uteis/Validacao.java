package uteis;

/**
 *
 * @author william.mauro
 */
public class Validacao {
   
    
}
